# 고물 철판 씬 전환 리소스

## 구성

- Sprites/plate_01_rust.png: 녹슨 철판과 사선 용접 자국
- Sprites/plate_02_teal.png: 벗겨진 청록 도장
- Sprites/plate_03_hazard.png: 노란 경고 줄무늬
- Sprites/plate_04_patch.png: 청록 보수판을 덧댄 철판
- Sprites/plate_05_ribbed.png: 회색 보강 철판
- Sprites/plate_06_crooked.png: 모서리가 잘린 청록 철판. 마지막 덜컹 동작에 사용
- Sprites/bolt.png: 늦게 떨어지는 볼트
- Sprites/weld_spark.png: 용접 불꽃 1장. 크기·회전·투명도를 짧게 애니메이션하는 용도이며 프레임 애니메이션 시트는 아님
- Audio/: 직접 합성한 44.1 kHz, 16-bit, mono WAV 6개. 실제 금속 녹음이 아닌 게임용 합성 효과음 초안

이미지는 내장 image_gen 도구로 생성했으며 원본 RGBA PNG를 보존했다. 생성 프롬프트는 PROMPTS.md에 기록했다. 도트풍 고해상도 이미지로, 고정된 저해상도 픽셀 격자에 수작업 정렬한 스프라이트는 아니다.

## Unity 적용

PNG를 Sprite (2D and UI), Single, Pivot Center, Mesh Type Full Rect로 가져온다. Filter Mode Point, Compression None, Generate Mip Maps Off, Wrap Mode Clamp를 시작값으로 사용한다. 원본을 유지하려면 Max Size 2048 이상을 사용한다. 투명 여백이 포함되어 있으므로 배치할 때 실제 철판 외곽을 기준으로 겹친다.

Canvas 아래 개별 UI Image로 배치하고 위치와 회전을 애니메이션한다. 철판 6장은 2열 × 3행 등으로 겹쳐 배치하되 화면 비율별로 전체 덮임을 확인한다. 이 이미지들은 정확히 맞물리는 퍼즐 조각이 아니다. 일부 철판 내부에도 미세한 반투명이 남아 있으므로, 전부 닫힌 순간 뒤에 완전 불투명한 어두운 UI Image를 활성화한 후 씬을 교체한다. 새 씬이 준비되면 배경 덮개를 해제하고 철판을 분리한다.

## 권장 연출 초안

| 시점 | 동작 | 효과음 |
|---|---|---|
| 0.00~0.32초 | 철판 1~5가 시차를 두고 날아와 충돌 | metal_clack / plate_slam |
| 0.32~0.42초 | 철판 6이 약간 기울어진 채 도착한 뒤 제자리로 덜컹 | plate_settle |
| 닫힘 직후 | 이음새 2~3곳에 불꽃을 0.08~0.15초 표시 | weld_crackle |
| 완전히 가린 동안 | 비동기 씬 로딩, 입력 및 전투 타이머 대기 | 필요시 무음 |
| 새 씬 준비 후 약 0.35초 | 철판을 바깥으로 분리 | plate_release |
| 분리 후 약 0.12초 | 볼트를 회전시키며 아래로 낙하시킴 | bolt_ting |

모든 시간은 조정용 제안값이다. 동시에 겹치는 효과음의 볼륨은 낮춰 믹싱한다. 실제 게임과 함께 청감 확인이 필요하다. 기존 씬 전환 코드와 프리팹 연결, Unity 플레이 검증은 이 리소스 제작에 포함하지 않았다.
